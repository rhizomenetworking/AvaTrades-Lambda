const index = require("./dist/index");
exports.handler = index.handler;